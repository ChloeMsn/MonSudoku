# MonSudoku
HAX815X Projet de programmation R - Generation de grille aleatoire de sudoku 


### DESCRIPTION 
This package contains functions to create a sudoku grid. 
A graphic interface is available with a shinyApp. 
You can choose the difficulty of the sudoku grid (in other words, how many boxes are hidden). 
You can test if a solution for the grid exists, if so, you can display the solution grid. 
